from django.apps import AppConfig


class AccountModuleConfig(AppConfig):
    name = 'account_module'
    verbose_name = 'کاربران'
