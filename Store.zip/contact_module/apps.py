from django.apps import AppConfig


class ContactModuleConfig(AppConfig):
    name = 'contact_module'
    verbose_name = 'ماژول ارتباط با ما'
