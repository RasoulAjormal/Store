from django.apps import AppConfig


class ArticlesModuleConfig(AppConfig):
    name = 'articles_module'
    verbose_name = 'مقالات'
