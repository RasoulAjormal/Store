from django.apps import AppConfig


class HomeModuleConfig(AppConfig):
    name = 'home_module'
