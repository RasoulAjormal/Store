from django.apps import AppConfig


class OrderModuleConfig(AppConfig):
    name = 'order_module'
    verbose_name = 'ماژول سبد خرید'
