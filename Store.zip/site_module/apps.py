from django.apps import AppConfig


class SiteModuleConfig(AppConfig):
    name = 'site_module'
    verbose_name = 'تنظیمات سایت'
