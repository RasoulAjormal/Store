from django.apps import AppConfig


class ProductModuleConfig(AppConfig):
    name = 'product_module'
    verbose_name = 'ماژول محصولات'
